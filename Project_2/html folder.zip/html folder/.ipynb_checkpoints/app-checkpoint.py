from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import hashlib

app = Flask(__name__)

@app.route('/')
def intro():
    return render_template('intro.html')

# Serve the index.html file
@app.route('/reconnaissance')
def level1():
    return render_template('reconnaissance.html')


# Handle path traversal challenge and template rendering
@app.route('/reconnaissance/<path:path>', methods=['GET'])
def navigate(path):
    # Validate the path and serve appropriate content or response
    if path == 'secret_login':
        return render_template('secret_login.html')
    else:
        return 'Path not found. Keep searching for clues!', 404


# Handle login form submission
@app.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    username = request.form.get('username')
    password = request.form.get('password')

    # Simulate login logic
    if email == 'b0ss@moebius.com' or (username == 'Hui Chan' and password == 'Assemblyman'):
        return f'Login successful! Welcome {password} + {username}'
    else:
        return 'Invalid credentials. Please try again.', 401


# # SQLite database initialization
# conn = sqlite3.connect('minions.db', check_same_thread=False)
# cursor = conn.cursor()
#
# # Create tables
# cursor.execute('''
#     CREATE TABLE IF NOT EXISTS minions (
#         id INTEGER PRIMARY KEY AUTOINCREMENT,
#         real_name TEXT NOT NULL,
#         address TEXT,
#         training_level TEXT,
#         skills TEXT
#
#
#     )
# ''')
#
# # Insert initial data
# cursor.execute('''
#     INSERT INTO minions (real_name, address, training_level, skills, crimes)
#     VALUES
#         ('Ma Dae Young', '105-10, Hanguk 1 chaapateu, Maetan 2(i)-dong,Gyeonggi-do', 'Pro', 'Martial Arts, Sniper','Murdered Park Deong Cheol'),
#         ('Jang Jun-woo', '125-6, Gajwa-dong, Incheon', 'Pro', 'Hacking','Hacked NSA')
# ''')
#
# conn.commit()
#
# @app.route('/search')
# def search():
#     search_query = request.args.get('query', '')
#
#     # Vulnerable SQL query (simulating SQL injection)
#     query = f"SELECT * FROM minions WHERE crimes LIKE '%{search_query}%'"
#
#     cursor.execute(query)
#     results = cursor.fetchall()
#
#     return jsonify(results)
#
# @app.route('/hidden-tables')
# def hidden_tables():
#     # Show hidden tables (for demonstration)
#     hidden_tables_info = [
#         {'name': 'fingerprints', 'description': 'Fingerprint data of criminals'}
#     ]
#
#     return jsonify(hidden_tables_info)
#
if __name__ == '__main__':
    app.run(debug=True)
#
#
#
